/*eslint-env node*/

//------------------------------------------------------------------------------
// node.js starter application for Bluemix
//------------------------------------------------------------------------------

// This application uses express as its web server
// for more info, see: http://expressjs.com
var express = require('express');

// cfenv provides access to your Cloud Foundry environment
// for more info, see: https://www.npmjs.com/package/cfenv
var cfenv = require('cfenv');

// create a new express server
var app = express();

// serve the files out of ./public as our main files
app.use(express.static(__dirname + '/public'));

// get the app environment from Cloud Foundry
var appEnv = cfenv.getAppEnv();


// start server on the specified port and binding host
app.listen(appEnv.port, '0.0.0.0', function() {
  // print a message when the server starts listening
  console.log("server starting on " + appEnv.url);
});
var  watson = require('watson-developer-cloud');

var tts_service_vcap = appEnv.services["text_to_speech"];

if (tts_service_vcap){
  var tts_credentials = tts_service_vcap[0].credentials;
  var textToSpeech = watson.text_to_speech({
    version: 'v1',
    username: tts_credentials.username,
    password: tts_credentials.password
  });

}
else{ 
  // (If you nedd to do local development, replace username and password)
  var textToSpeech = watson.text_to_speech({
    version: 'v1',
    username: '', // provide username from service credentials
    password: '' // provide password from service credentials
  });
}

// Handle text to speech request from client
app.get('/api/synthesize', function(req, res, next) {
  var transcript = textToSpeech.synthesize(req.query);
  transcript.on('response', function(response) {
    if (req.query.download) {
      response.headers['content-disposition'] = 'attachment; filename=transcript.ogg';
    }
  });
  transcript.on('error', function(error) {
    next(error);
  });
  transcript.pipe(res);
});
